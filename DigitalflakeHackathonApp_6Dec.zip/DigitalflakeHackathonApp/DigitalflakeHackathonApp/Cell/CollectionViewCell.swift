//
//  CollectionViewCell.swift
//  DigitalflakeHackathonApp
//
//  Created by user242471 on 12/5/23.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var viewSlotsBg: UIViewX!
    @IBOutlet weak var lblSlots: UILabel!
}
